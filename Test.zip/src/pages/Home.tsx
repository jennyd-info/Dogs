import { FunctionComponent } from "react";
import styles from "./Home.module.css";

const Home: FunctionComponent = () => {
  return (
    <div className={styles.home}>
      <header className={styles.navBar}>
        <div className={styles.ourDogs}>Our dogs:</div>
        <div className={styles.bestShots}>Best shots</div>
      </header>
      <section className={styles.images}>
        <img
          className={styles.fordIcon}
          loading="eager"
          alt=""
          src="/ford@2x.png"
        />
        <img
          className={styles.maddisonIcon}
          loading="eager"
          alt=""
          src="/maddison@2x.png"
        />
      </section>
    </div>
  );
};

export default Home;
